# Data 1
username=input("Enter your Name: ")
password=input("Enter Password: ")
emailVerified = False
if username=="shahroze" and password=="123456":
    if emailVerified==True:
        print("Login Successfully")
    else:
        print("Login Failed")
# Data 2
username=input("Enter your Name: ")
password=input("Enter Password: ")
emailVerified = True
if username=="shahroze" and password=="123456":
    if emailVerified==True:
        print("Login Successfully")
else:
    print("Login Failed")